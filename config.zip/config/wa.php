<?php

return [
    'wa_apikey' => env('WA_APIKEY', ''),
    'wa_apiurl' => env('WA_APIURL', '')
];
