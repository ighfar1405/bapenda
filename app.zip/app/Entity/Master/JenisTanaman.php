<?php

namespace App\Entity\Master;

use Illuminate\Database\Eloquent\Model;

class JenisTanaman extends Model
{
    /**
     * Definde table name
     */
    protected $table = 'jenis_tanaman';
}
